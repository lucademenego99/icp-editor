importScripts("classes.js");
// @ts-ignore - main will be defined by the previous importScript
main();